#define SIZE 8
#include "posstack1.h"
posit CWL(posit a);

posit CWR(posit a);

posit CWF(posit a);

posit CWB(posit a);
