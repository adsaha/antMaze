#include "posstack1.h"
#define SIZE 8
void MOVE_F();

void MOVE_B();

void MOVE_L();

void MOVE_R();

void Mark();

void BJPI(posit b);

void CJPI(posit b);

void energy(int c);

void backtrack(posit aux);

